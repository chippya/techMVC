<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index()
	{
		$name="chippy";
		//return "haiii";
		//return view('pages.index');
		//return view('pages.index',compact('name'));
		return view('pages.index')->with('titles',$name);
	}
	 public function about()
	{
		//return "haiii";
		return view('pages.about');
		//return view('pages.service');
	}
	 public function service()
	{
		//return "haiii";
		return view('pages.service');
		//return view('pages.service');
	}
}
