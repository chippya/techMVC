<?php $__env->startSection('content'); ?>
<h1>home</h1>
<h2><?php echo e($titles); ?></h2>

<P> haiiiiiiiiiii<p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>