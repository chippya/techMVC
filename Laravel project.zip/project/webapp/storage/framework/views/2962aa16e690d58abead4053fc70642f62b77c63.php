<form method="post" action="<?php echo e(route('shares.store')); ?>">
<?php echo csrf_field(); ?>
<table>
<tr> 
<td>Title</td>
<td><input type="text" name="title1"></td>
</tr>
<tr>
<td> Body</td>
<td><input type="text" name="body"></td>
</tr>
<tr>
<td><input type="submit" name="submit"></td>
</tr>
</table>
</form>