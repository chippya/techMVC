<table border="1">
<tr>
<td>id</td>
<td>title</td>
<td>body</td>
<td>edit</td>
<td>delete</td>
</tr>
@foreach($share as $value)
<tr>
<td>{{$value->id}}</td>
<td>{{$value->title}}</td>
<td>{{$value->body}}</td>
</tr>
@endforeach

</table>
