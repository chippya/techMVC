
@extends('layout.app')
@section('content')
<h1>home</h1>
<h2>{{$titles}}</h2>

<P> haiiiiiiiiiii<p>
@endsection