<?php
    include  ('dbconnection.php');

    if(isset($_POST['sign']))
    {
		
        $name = $_POST['name'];
        $age = $_POST['age'];
		$dob= $_POST['dob'];
		$address= $_POST['address'];
		$place = $_POST['place'];
		$district = $_POST['district'];
		$phno = $_POST['phno'];
		
		$mstatus = $_POST['mstatus'];
		 $email = $_POST['email'];
        $pwd = $_POST['pwd'];

        $qry = "INSERT INTO registration (name,age,dob,address,place,district,phno,mstatus,email,pwd) VALUES ('$name',$age,'$dob','$address','$place','$district','$phno','$mstatus','$email','$pwd')";
        $res = mysqli_query($conn,$qry);

        
    }
	
?>




<html>
<head>
<title>
 sign in
</title>
<style>


</style>

</head>
<body text="black"  height="100" width="200">

    <h1>REGISTRATION</h1>
    <form action='#' method='post' style='text-align:center;'>
	 <div class="imgcontainer">
   
  </div>
        
           
        Name          : <input type='text' name='name'><br><br>
        Age           : <input type='text' name='age'><br><br>
		DOB           : <input type='text'name='dob'><br><br>
		Gender        : <input type='radio'name='male'>male</input>
		                <input type='radio'name='female'>female</input><br><br>
		Address       : <input type='text' name='address'><br><br>
		Place         : <input type='text' name='place'><br><br>
		District      : <input type='text' name='district'><br><br>
		Phone No      : <input type='text' name='phno'><br><br>
		
        Status: <input type='text' name='mstatus'><br><br>
		E-mail ID     : <input type='text' name='email'><br><br>
		Password      : <input type='password' name='pwd'><br><br>
             <input type='submit' name='sign' value='REGISTER'>
			 <input type='reset' name='reset' value='RESET'><br><br><br>
            
       
        <div>
        </div>

      
        <li><a href="login.php">LOGIN</a></li>
    </form>
</body>
</html>