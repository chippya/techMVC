<?php
    include( 'dbconnection.php');

    if(isset($_POST['sign']))
    {
		
        $email = $_POST['uname'];
		$pwd = $_POST['pwd'];

        $qry = "select pwd from registration where email='$email'";
        $result = mysqli_query($conn,$qry);
		$row = mysqli_fetch_assoc($result);
        if($row['pswd']==$pwd)
        {
           header('location:home.php');
			// echo 'successfull';
			
        }
		else{
			echo "<script>alert('error login')</sctipt>";
		}
        
    }
?>



<html>
<head>
<title>LOGIN</title>
</head>
<body>
 
<form action="#"  method='post'>



  
		<label><b>Username</b></label>
		<input type="text" placeholder="Enter Username" name="uname" required><br><br><br>

		<label><b>Password</b></label>
		<input type="password" placeholder="Enter Password" name="psw" required><br><br><br><br><br>
   
   

<center> <button type="submit" name='sign' value='sign'>Login</button><center><br><br><br>
  </div>
</form>
</center>
</body>
</html>