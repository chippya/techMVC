<?php
include ('db.php'); 
if(isset($_POST['btn1']))
{
	$a=$_POST["name"];
	$b=$_POST["address"];
	$c=$_POST["mb"];
	
	$sql="insert into reg(name,address,mb)values('$a','$b', '$c')";
	$res=mysqli_query($con,$sql);
	echo "values entered";
	
}
?>
<?php
if(isset($_POST['btn2']))
{
	
	$q="select * from reg ";
	$res=mysqli_query($con,$q);
	?>
	<table>
	<tr>
	<th>name</Th> 
	<th>address</Th>
	<th>mb</Th>
	
	</tr>
	<?php
	while($con=mysqli_fetch_array($res))
	{
		
		?>
		<tr>
		<td>
		<?php 
		echo "$q[0]";
		?>
		</td>
		<td>
		<?php 
		echo " $q[1]";
		?>
		</td>
		<td>
		<?php 
		echo "$q[2]";
		?>
		</td>
		
	<?php
		}
		?>
	</table>
		<?php
		
	}
	?> 
	
<html>
<body>
<form action="#" method="POST">
<table>
<tr>
<td>
NAME
</td>
<td><input type =text name= name id ="name"></td>
</tr>
<tr>
<td>
Address
</td>
<td><input type =text name= address id ="address"></td>
</tr>
<tr>
<td>
Mobile Number
</td>
<td><input type =text name=mb id ="mb"></td>
</tr>
<tr>

<td><input type =submit name =btn1 id= "btn1" value =ADD></td>
<td><input type =submit name =btn1 id= "btn2" value =View></td>
</tr>
</table>
</body>
</html>