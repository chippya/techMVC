
<?php
include ('db.php'); 

	$q="select * from reg ";
	$res=mysqli_query($con,$q);
	?>
	<table>
	<tr>
	<th>name</Th> 
	<th>address</Th>
	<th>mb</Th>
	
	</tr>
	<?php
	while($q1=mysqli_fetch_array($res))
	{
		
		?>
		<tr>
		
		<td>
		<?php 
		echo " $q1[1]";
		?>
		</td>
		<td>
		<?php 
		echo "$q1[2]";
		?>
		</td>
		<td>
		<?php 
		echo "$q1[3]";
		?>
		</td>
		</tr>
	<?php
		}
		?>
	</table>
	
	<html>
	<body>
	<td><input type =submit name =btn2 id= "btn2" value =ADD></td>
	</body>
	</html>