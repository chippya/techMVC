<?php

if(isset($_GET["cid"]))
{
	require("connect.php");
	$cid=$_GET["cid"];
	$query="delete from tb_courses where cid=$cid";
	mysql_query($query);
}

header("location:courses.php");

?>